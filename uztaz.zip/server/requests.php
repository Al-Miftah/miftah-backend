<?php
include_once 'inc/check_login_status.php';
extract($_GET);


// Allow from any origin
if (isset($_SERVER['HTTP_ORIGIN'])) {
    // should do a check here to match $_SERVER['HTTP_ORIGIN'] to a
    // whitelist of safe domains
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");         

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

}


//admin

if($op == 'getadmin'){
	$q = mysqli_query($db_conx,"SELECT * FROM admin WHERE type != 'System Admin'");
	$arr = [];
	while ($row = mysqli_fetch_array($q,MYSQLI_ASSOC)) {
	   $arr[] = $row;
	};
	print json_encode($arr);
}

if($op == 'deleteAdmin'){
    $q1 = mysqli_query($db_conx,"SELECT usertype FROM admin WHERE  id = '$log_id'");
    $r1 = mysqli_fetch_array($q1, MYSQLI_ASSOC);
    if($r1['usertype'] === 'c'){
		$q = mysqli_query($db_conx,"SELECT usertype FROM admin WHERE  id = '$id'");
		if(mysqli_num_rows($q) > 0){
			$row = mysqli_fetch_array($q, MYSQLI_ASSOC);
			if($row['usertype'] === 'c'){
				print json_encode(array('error' => true,'answer' => 'You are not eligible to remove this user'));
				exit;
			}
			$query = mysqli_query($db_conx,"DELETE FROM admin WHERE  id = '$id'");
			if($query){
				print json_encode(array('error' => false,'answer' => 'Success'));
			}
		}else{
			print json_encode(array('error' => true,'answer' => 'This user does not exist'));
	   }
	}else{
		print json_encode(array('error' => true,'answer' => 'You are not eligible to remove this user'));
	}
}   

if($op == 'getAdminById'){
	$q = mysqli_query($db_conx,"SELECT * FROM admin WHERE id = '$id'");
	$r1 = mysqli_fetch_array($q,MYSQLI_ASSOC);
	print json_encode($r1);
}


//channel

if($op == 'getchannels'){
	$q = mysqli_query($db_conx,"SELECT * FROM channel");
	$arr = [];
	while ($row = mysqli_fetch_array($q,MYSQLI_ASSOC)) {
	   $arr[] = $row;
	};
	print json_encode($arr);
}

if($op == 'deleteChannel'){
    $query = mysqli_query($db_conx,"DELETE FROM channel WHERE  id = '$id'");
	if($query){
		print json_encode(array('error' => false,'answer' => 'Success'));
	}else{
		print json_encode(array('error' => true,'answer' => 'Unable to delete this channel'));
	}
}   

if($op == 'getChannelById'){
	$q = mysqli_query($db_conx,"SELECT * FROM channel WHERE id = '$id'");
	$r1 = mysqli_fetch_array($q,MYSQLI_ASSOC);
	print json_encode($r1);
}

//playlist

if($op == 'getPlaylistByChannel'){
	$q = mysqli_query($db_conx,"SELECT * FROM playlist WHERE channel_id = '$id'");
	$arr = [];
	while ($row = mysqli_fetch_array($q,MYSQLI_ASSOC)) {
	   $arr[] = $row;
	};
	print json_encode($arr);
}

if($op == 'deletePlaylist'){
    $query = mysqli_query($db_conx,"DELETE FROM playlist WHERE  id = '$id'");
	if($query){
		print json_encode(array('error' => false,'answer' => 'Success'));
	}else{
		print json_encode(array('error' => true,'answer' => 'Unable to delete this channel'));
	}
}   

if($op == 'getPlaylistById'){
	$q = mysqli_query($db_conx,"SELECT * FROM playlist WHERE id = '$id'");
	$r1 = mysqli_fetch_array($q,MYSQLI_ASSOC);
	print json_encode($r1);
}

//content

if($op == 'getContentByChannelAndPlaylist'){
	$q = mysqli_query($db_conx,"SELECT * FROM content WHERE channel_id = '$channel' AND playlist_id = '$playlist'");
	$arr = [];
	while ($row = mysqli_fetch_array($q,MYSQLI_ASSOC)) {
	   $arr[] = $row;
	};
	print json_encode($arr);
}

if($op == 'deleteContent'){
    $query = mysqli_query($db_conx,"DELETE FROM content WHERE  id = '$id'");
	if($query){
		print json_encode(array('error' => false,'answer' => 'Success'));
	}else{
		print json_encode(array('error' => true,'answer' => 'Unable to delete this channel'));
	}
}   

if($op == 'getContentById'){
	$q = mysqli_query($db_conx,"SELECT * FROM content WHERE id = '$id'");
	$r1 = mysqli_fetch_array($q,MYSQLI_ASSOC);
	print json_encode($r1);
}

if($op == 'getRecentContent') {
	$q = mysqli_query($db_conx,"SELECT * FROM content ORDER BY dateadded DESC LIMIT 10");
	$arr = [];
	while ($row = mysqli_fetch_array($q, MYSQLI_ASSOC)) {
		$channelId = $row['channel_id'];
		$playlistId = $row['playlist_id'];
		$admin_id = $row['admin_id'];

		$ch = mysqli_fetch_array(mysqli_query($db_conx, "SELECT * FROM channel WHERE id = '$channelId' LIMIT 1"), MYSQLI_ASSOC);

		$pl = mysqli_fetch_array(mysqli_query($db_conx, "SELECT * FROM playlist WHERE id = '$playlistId' LIMIT 1"), MYSQLI_ASSOC);

		$ad = mysqli_fetch_array(mysqli_query($db_conx, "SELECT * FROM admin WHERE id = '$admin_id' LIMIT 1"), MYSQLI_ASSOC);

		$info = array(
		  'id'=> $row['id'],
		  'title'=> $row['title'],
		  'admin'=> $ad,
		  'channel'=> $ch,
		  'playlist'=> $pl,
		  'type'=> $row['type'],
		  'views'=> $row['views'],
		  'likes'=> $row['likes'],
		  'dislikes'=> $row['dislikes'],
		  'url'=> $row['url'],
		  'source'=> $row['source'],
		  'dateadded'=> $row['dateadded'],
		);
		array_push($arr, $info);
	};
	print json_encode($arr);
}