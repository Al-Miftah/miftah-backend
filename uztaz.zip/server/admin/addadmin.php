<?php
    include_once '../inc/imageProcess.php';
    include_once '../inc/check_login_status.php';


    $admin = json_decode(file_get_contents("php://input"),true);


    $name = mysqli_real_escape_string($db_conx, $admin['name']);
    $email = mysqli_real_escape_string($db_conx, $admin['email']);
    $pass = mysqli_real_escape_string($db_conx, $admin['pass']);
    $pass1 = mysqli_real_escape_string($db_conx, $admin['pass1']);
    $pass2 = mysqli_real_escape_string($db_conx, $admin['pass2']);
    $type = mysqli_real_escape_string($db_conx, $admin['type']);
    $avatar = mysqli_real_escape_string($db_conx, $admin['avatar']);
    $status = mysqli_real_escape_string($db_conx, $admin['status']);
    $token = mysqli_real_escape_string($db_conx, $admin['token']);
    

    if($status == 'create'){

        if($name == "" || $email == "" || $pass1 == "" || $pass2 == "" || $type == "" ){
            echo json_encode( array('error'=>true,'answer' => 'Fill the form data') );
            exit;
        }
    
    
        if($pass1 != $pass2){
            echo json_encode( array('error'=>true,'answer' => 'Passwords must match') );
            exit;
        }
    

        $q = mysqli_query($db_conx,"SELECT id FROM admin WHERE email = '$email'");
        if(mysqli_num_rows($q) > 0){
            echo json_encode( array('error'=>true,'answer' => 'This email already exists') );
            exit;
         }

         $query = mysqli_query($db_conx, "INSERT INTO admin(name,email,type,password,dateadded) VALUES ('$name','$email','$type',md5('$pass1'),now())");
        if($query){
           echo json_encode( array('error'=>false,'answer' => 'success') );
           exit;
         }
    } 


    
    if($status == 'update'){

        if($name == "" || $email == "" ||  $type == "" ){
            echo json_encode( array('error'=>true,'answer' => 'Fill the form data') );
            exit;
        }

        $q1 = mysqli_query($db_conx,"SELECT email FROM admin WHERE  id = '$log_id'");
        if(mysqli_num_rows($q1) > 0){
            $r1 = mysqli_fetch_array($q1,MYSQLI_ASSOC);
            if($r1['email'] !== $email){
                $q = mysqli_query($db_conx,"SELECT id FROM admin WHERE email = '$email'");
                if(mysqli_num_rows($q) > 0){
                    echo json_encode( array('error'=>true,'answer' => 'This email already exists') );
                    exit;
                 }
            }
        }

        $query = mysqli_query($db_conx, "UPDATE admin SET email = '$email' , name = '$name', avatar = '$avatar' WHERE id = '$log_id'");
        if($query){
           $q3 = mysqli_query($db_conx,"SELECT * FROM admin WHERE  id = '$log_id'");
           $row = mysqli_fetch_array($q3,MYSQLI_ASSOC);
           print json_encode(array('loggedIn'=>true,'token'=>$token,'userid'=>$_SESSION['userid'],'email'=>$_SESSION['email'],'password'=>$_SESSION['password'],'avatar'=>$row['avatar'],'name'=>$row['name'],'type'=>$row['type'],'dateadded'=>$row['dateadded'],'lastlogin'=>$row['lastlogin']));
        }
    }

    

    if($status === 'change_pass') {

        if($pass1 != $pass2){
            echo json_encode( array('error'=>true,'answer' => 'Passwords must match') );
            exit;
        }

        $q = mysqli_query($db_conx,"SELECT id FROM admin WHERE password = md5('$pass')");
        if(mysqli_num_rows($q) < 1){
            echo json_encode( array('error'=>true,'answer' => 'Incorrect password') );
            exit;
         }
         $query = mysqli_query($db_conx, "UPDATE admin SET password = md5('$pass1')  WHERE id = '$log_id'");
         if($query){
            $q3 = mysqli_query($db_conx,"SELECT * FROM admin WHERE  id = '$log_id'");
            $row = mysqli_fetch_array($q3,MYSQLI_ASSOC);
            print json_encode(array('loggedIn'=>true,'token'=>$token,'userid'=>$_SESSION['userid'],'email'=>$_SESSION['email'],'password'=>$_SESSION['password'],'avatar'=>$row['avatar'],'name'=>$row['name'],'type'=>$row['type'],'dateadded'=>$row['dateadded'],'lastlogin'=>$row['lastlogin']));
         }

    }
