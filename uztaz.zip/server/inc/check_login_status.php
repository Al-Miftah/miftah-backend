<?php
session_start();
include_once("db_conx.php");
$user_ok = false;
$log_id = "";
$log_password = "";
function evalLoggedUser($conx,$id,$p){
    $query = mysqli_query($conx, "SELECT id FROM admin WHERE id='$id' AND password='$p' LIMIT 1");
    $numrows = mysqli_num_rows($query);
    if($numrows > 0){
        return true;
    }
}
if(isset($_SESSION["userid"]) && isset($_SESSION["password"])) {
    $log_id = preg_replace('#[^0-9]#', '', $_SESSION['userid']);
    $log_password = preg_replace('#[^a-z0-9]#i', '', $_SESSION['password']);
    $user_ok = evalLoggedUser($db_conx,$log_id,$log_password);
} else if(isset($_COOKIE["id"]) && isset($_COOKIE["pass"])){
    $_SESSION['userid'] = preg_replace('#[^0-9]#', '', $_COOKIE['id']);
    $_SESSION['password'] = preg_replace('#[^a-z0-9]#i', '', $_COOKIE['pass']);
    $log_id = $_SESSION['userid'];
    $log_password = $_SESSION['password'];
    $user_ok = evalLoggedUser($db_conx,$log_id,$log_password);
    if($user_ok == true){
        $query = mysqli_query($db_conx, "UPDATE admin SET lastlogin=now() WHERE id='$log_id' LIMIT 1");
    }
}