<?php
 $db_conx = mysqli_connect("localhost", "halalclo_aditek", "@Adi0100201031", "halalclo_daawaApp");
//  $db_conx = mysqli_connect("localhost", "root", "", "ustaz");

//a5557617_agh 	a5557617_agh