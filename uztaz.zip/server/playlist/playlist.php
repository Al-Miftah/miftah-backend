<?php
    include_once '../inc/imageProcess.php';
    include_once '../inc/check_login_status.php';


    $channel = json_decode(file_get_contents("php://input"),true);


    $name = mysqli_real_escape_string($db_conx, $channel['name']);
    $channel_id = mysqli_real_escape_string($db_conx, $channel['channel_id']);
    $content_type = mysqli_real_escape_string($db_conx, $channel['content_type']);
    $status = mysqli_real_escape_string($db_conx, $channel['status']);
    $id = mysqli_real_escape_string($db_conx, $channel['id']);
    
    
    if($name == "" || $channel_id == "" || $content_type == ""){
        echo json_encode( array('error'=>true,'answer' => 'Fill the form data') );
        exit;
    }

    if($status == 'create'){

        $query = mysqli_query($db_conx, "INSERT INTO playlist(name,channel_id,content_type,dateadded)  VALUES ('$name','$channel_id','$content_type',now())");
        if($query){
           echo json_encode( array('error'=>false,'answer' => 'success') );
           exit;
         }
    } 


    
    if($status == 'update'){

        $query = mysqli_query($db_conx, "UPDATE playlist SET name = '$name' , channel_id = '$channel_id', content_type = '$content_type' WHERE id = '$id'");
        if($query){
           $q3 = mysqli_query($db_conx,"SELECT * FROM playlist WHERE  id = '$id'");
           $row = mysqli_fetch_array($q3,MYSQLI_ASSOC);
           print json_encode($row);
        }
    }
