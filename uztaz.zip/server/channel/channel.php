<?php
    include_once '../inc/imageProcess.php';
    include_once '../inc/check_login_status.php';


    $channel = json_decode(file_get_contents("php://input"),true);


    $name = mysqli_real_escape_string($db_conx, $channel['name']);
    $email = mysqli_real_escape_string($db_conx, $channel['email']);
    $phone = mysqli_real_escape_string($db_conx, $channel['phone']);
    $address = mysqli_real_escape_string($db_conx, $channel['address']);
    $avatar = $channel['avatar'];
    $about = mysqli_real_escape_string($db_conx, $channel['about']);
    $links = $channel['links'];
    $status = mysqli_real_escape_string($db_conx, $channel['status']);
    $id = mysqli_real_escape_string($db_conx, $channel['id']);
    
    
    if($name == "" || $phone == "" || $address == "" || $about == ""){
        echo json_encode( array('error'=>true,'answer' => 'Fill the form data') );
        exit;
    }

    if($status == 'create'){

        $query = mysqli_query($db_conx, "INSERT INTO channel(name,email,phone,address,avatar,about,links,dateadded)  VALUES ('$name','$email','$phone','$address','$avatar','$about','$links',now())");
        if($query){
           echo json_encode( array('error'=>false,'answer' => 'success') );
           exit;
         }
    } 


    
    if($status == 'update'){

        $query = mysqli_query($db_conx, "UPDATE channel SET name = '$name' , email = '$email', phone = '$phone', address = '$address',  about = '$about',  links = '$links', avatar = '$avatar' WHERE id = '$id'");
        if($query){
           $q3 = mysqli_query($db_conx,"SELECT * FROM channel WHERE  id = '$log_id'");
           $row = mysqli_fetch_array($q3,MYSQLI_ASSOC);
           print json_encode($row);
        }
    }
