<?php
include_once("../inc/db_conx.php");
$user = json_decode(file_get_contents("php://input"),true);
$token = mysqli_real_escape_string($db_conx, $user['token']);
$id = mysqli_real_escape_string($db_conx, $user['id']);

session_id('userid');
$query = mysqli_query($db_conx,"UPDATE admin SET token= '', WHERE id = '$id'");
if($query){
      session_start();
// Set Session data to an empty array
	$_SESSION = array();
	// Expire their cookie files
	if(isset($_COOKIE["id"]) && isset($_COOKIE["user"]) && isset($_COOKIE["pass"])) {
	    setcookie("id", '', strtotime( '-5 days' ), '/');
	    setcookie("user", '', strtotime( '-5 days' ), '/');
	    setcookie("pass", '', strtotime( '-5 days' ), '/');
	}
	session_destroy();
	session_commit(); 
	print json_encode(array('loggedOut'=>true));
}