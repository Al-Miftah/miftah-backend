<?php
    include_once '../inc/imageProcess.php';
    include_once '../inc/check_login_status.php';


    $content = json_decode(file_get_contents("php://input"),true);


    $title = mysqli_real_escape_string($db_conx, $content['title']);
    $playlist_id = mysqli_real_escape_string($db_conx, $content['playlist_id']);
    $channel_id = mysqli_real_escape_string($db_conx, $content['channel_id']);
    $admin_id = mysqli_real_escape_string($db_conx, $content['admin_id']);
    $type = mysqli_real_escape_string($db_conx, $content['type']);
    $views = mysqli_real_escape_string($db_conx, $content['views']);
    $likes = mysqli_real_escape_string($db_conx, $content['likes']);
    $dislikes = mysqli_real_escape_string($db_conx, $content['dislikes']);
    $url = mysqli_real_escape_string($db_conx, $content['url']);
    $status = mysqli_real_escape_string($db_conx, $content['status']);
    $id = mysqli_real_escape_string($db_conx, $content['id']);
    
    
    if($title == "" || $type == "" || $url == ""){
        echo json_encode( array('error'=>true,'answer' => 'Fill the form data') );
        exit;
    }

    if($status == 'create'){

        $query = mysqli_query($db_conx, "INSERT INTO content(title,admin_id,channel_id,playlist_id,type,url,dateadded) 
                                                 VALUES ('$title','$admin_id','$channel_id','$playlist_id','$type','$url',now())");
        if($query){
           echo json_encode( array('error'=>false,'answer' => 'success') );
           exit;
         }
    } 


    
    if($status == 'update'){

        $query = mysqli_query($db_conx, "UPDATE content SET title = '$title', playlist_id = '$playlist_id', type = '$type',  url = '$url',  source = '$source' WHERE id = '$id'");
        if($query){
           $q3 = mysqli_query($db_conx,"SELECT * FROM content WHERE  id = '$id'");
           $row = mysqli_fetch_array($q3,MYSQLI_ASSOC);
           print json_encode($row);
        }
    }
