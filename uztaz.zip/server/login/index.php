<?php
include_once("../inc/db_conx.php");
$user = json_decode(file_get_contents("php://input"),true);
$e = mysqli_real_escape_string($db_conx, $user['email']);
$p = mysqli_real_escape_string($db_conx, $user['password']);
$p_hash = md5($p);

$query = mysqli_query($db_conx,"SELECT * FROM admin WHERE email = '$e' AND password = '$p_hash'");
$numrows = mysqli_num_rows($query);
if($numrows > 0){
    $row = mysqli_fetch_array($query, MYSQLI_ASSOC);
    $db_id = $row['id'];
    $db_lastlogin = $row['lastlogin'];
    session_start();
    $_SESSION['userid'] = $row['id'];
    $_SESSION['email'] = $row['email'];
    $_SESSION['password'] = $row['password'];
    setcookie("id", $row['id'], strtotime( '+30 days' ), "/", "", "", TRUE);
    setcookie("user", $row['email'], strtotime( '+30 days' ), "/", "", "", TRUE);
    setcookie("pass", $row['password'], strtotime( '+30 days' ), "/", "", "", TRUE);
    $token = bin2hex(openssl_random_pseudo_bytes(64));
    $query = mysqli_query($db_conx,"UPDATE admin SET token= '$token', lastlogin = '$db_lastlogin' WHERE id = '$db_id'");
    print json_encode(array('loggedIn'=>true,'token'=>$token,'userid'=>$_SESSION['userid'],'email'=>$_SESSION['email'],'password'=>$_SESSION['password'],'avatar'=>$row['avatar'],'name'=>$row['name'],'type'=>$row['type'],'dateadded'=>$row['dateadded'],'lastlogin'=>$row['lastlogin']));
  
}else{
    header('HTTP/1.1 401 Unauthorized', true, 401);
    exit;
}
