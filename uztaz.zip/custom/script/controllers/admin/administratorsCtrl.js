/**
 * Created by Aditech on 5/30/2016.
 */
(function () {
    'use strict';
    angular.module("myApp").controller('administratorsCtrl', ['$scope','auth', function ($scope,auth) {

       }])
})();
